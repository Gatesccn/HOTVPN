#!/bin/sh
echo "Make sure to have Node.JS installed and added to your PATH variables."
sleep 5
npm update --save
exit